import React, { useState } from 'react';
import { Card, Button, Modal, Form } from 'react-bootstrap';
import './cardComp.css';

const CardComp = ({ title, description, alertDesc }) => {
    const [showModal, setShowModal] = useState(false);
    const [textInput, setTextInput] = useState('');
    const [submitted, setSubmitted] = useState(false); // State to track if form is submitted

    const handleCardClick = () => {
        setShowModal(true);
    };

    const handleCloseModal = () => {
        setShowModal(false);
    };

    const handleInputChange = (event) => {
        setTextInput(event.target.value);
    };

    const handleSave = () => {
        setShowModal(false);
        setSubmitted(true); // Set submitted state to true
        setTextInput('');
    };

    return (
        <>
        <link rel="preconnect" href="https://fonts.googleapis.com"/>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400..900&display=swap" rel="stylesheet"></link>
            <div onClick={handleCardClick}>
                <Card style={{ width: '18rem', borderRadius: '20px', backgroundColor: submitted ? 'lightcoral' : 'inherit', color: submitted ? 'white' : 'inherit' }} className='mx-5 my-5 custom-card' id='custom-card'>
                    <Card.Body>
                        <Card.Title>{title}</Card.Title>
                        <Card.Text>{description}</Card.Text>
                    </Card.Body>
                </Card>
            </div>

            <Modal  id = "modal" show={showModal} onHide={handleCloseModal} centered>
            <link rel="preconnect" href="https://fonts.googleapis.com"/>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
<link href="https://fonts.googleapis.com/css2?family=Genos:ital,wght@0,100..900;1,100..900&family=Orbitron:wght@400..900&display=swap" rel="stylesheet"/>
                <Modal.Header closeButton>
                    <Modal.Title>{title}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <p>{alertDesc}</p>
                    <Form>
                        <Form.Group controlId="formTextInput">
                            <Form.Label className='mt-3'>Your response :</Form.Label>
                            <Form.Control type="text" value={textInput} onChange={handleInputChange} placeholder="CTF(...)" />
                        </Form.Group>
                    </Form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleCloseModal}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={handleSave}>
                        Submit
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
}

export default CardComp;
